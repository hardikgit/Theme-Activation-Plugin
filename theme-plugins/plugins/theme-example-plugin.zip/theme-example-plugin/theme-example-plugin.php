<?php
/**
 * @wordpress-plugin
 * Plugin Name: Theme Example Plugin
 * Description: This is an example plugin to going along with the TGM Plugin Activation class.
 * Author:      Thomas Griffin
 * Version:     1.0.1
 * Text Domain: theme-example-plugin
 * Domain Path: /languages

 */

// Avoid direct calls to this file.
if ( ! function_exists( 'add_action' ) ) {
	header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
	exit();
}

if ( ! function_exists( 'theme_php_mysql_versions' ) ) {

	add_action( 'rightnow_end', 'theme_php_mysql_versions', 9 );

	/**
	 * Displays the current server's PHP and MySQL versions right below the WordPress version
	 * in the Right Now dashboard widget.
	 *
	 * @since 1.0.0
	 */
	function theme_php_mysql_versions() {
		echo wp_kses(
			sprintf(
				/* TRANSLATORS: %1 = php version nr, %2 = mysql version nr. */
				__( '<p>You are running on <strong>PHP %1$s</strong> and <strong>MySQL %2$s</strong>.</p>', 'theme-example-plugin' ),
				phpversion(),
				$GLOBALS['wpdb']->db_version()
			),
			array(
				'p' => array(),
				'strong' => array(),
			)
		);
	}
}
